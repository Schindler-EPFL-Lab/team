# Robot Web Server 2

[![Build Status](https://dev.azure.com/devsdb/CRD-NT_ARCO/_apis/build/status/rws2?branchName=refs%2Fpull%2F12569%2Fmerge)](https://dev.azure.com/devsdb/CRD-NT_ARCO/_build/latest?definitionId=854&branchName=refs%2Fpull%2F12569%2Fmerge)

This package provides code to interact with [ABB robot web service](https://developercenter.robotstudio.com/api/RWS?urls.primaryName=Introduction).
Tested and developed for version `3HAC073675-001 Revision:D`.

Code updated from [ABB Robot Web Service](https://github.com/prinsWindy/ABB-Robot-Machine-Vision/tree/master/RobotWebServices).
